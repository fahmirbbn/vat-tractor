<?php $__env->startSection('content'); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Animated Login Form</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Poppins:600&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/a81368914c.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <img class="wave" src="<?php echo e(asset('assets/img/wave.png')); ?>">
    <div class="container">
        <div class="img">
            <img src="<?php echo e(asset('assets/img/logos-tractor.png')); ?>">
        </div>
        <div class="login-content">
            <form method="POST" action="<?php echo e(route('auth.login')); ?>">
                <?php echo csrf_field(); ?> 

                <img src="<?php echo e(asset('assets/img/avatar.svg')); ?>">
                <h2 class="title">VAT Thunder 1.0</h2>
                <div class="input-div one">
                    <div class="i">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="div">
                        <h5>Username</h5>
                        <input type="text" class="input" name="email" value="<?php echo e(old('email') ?? ''); ?>" required autofocus autocomplete="off">
                    </div>
                </div>
                <div class="input-div pass">
                    <div class="i"> 
                        <i class="fas fa-lock"></i>
                    </div>
                    <div class="div">
                        <h5>Password</h5>
                        <input type="password" class="input" name="password" required>
                    </div>
                </div>
                
                <input type="submit" class="btn" value="Login">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
    <script type="text/javascript" src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
</body>
</html>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fahmi.robbani\Desktop\laravel9-template-main\resources\views/auth/login.blade.php ENDPATH**/ ?>