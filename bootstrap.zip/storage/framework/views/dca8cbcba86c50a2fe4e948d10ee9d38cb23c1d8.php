

<?php $__env->startSection('title', 'Rencana Kerja'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Rencana Kerja</h1>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('index')); ?>">Dashboard</a></li>
                            <li class="breadcrumb-item active">Rencana Kerja</li>
                        </ol>
                    </div>
                </div>
            </div>
        </section>
        <?php echo $__env->make('admin.includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <section class="content">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Data</h3>
                    <div class="card-tools">
                        <a href="<?php echo e(route('admin.rencana_kerja.create')); ?>" class="btn btn-primary"><i class="fas fa-plus"></i> Create</a>
                    </div>
                </div>
                <div class="card-body">
                    <table id="tb_data" class="table table-bordered table-hover dataTable dtr-inline" style="width:100%">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Location Code</th>
                                <th>Unit Name</th>
                                <th>Implement Name</th>
                                <th>Activity Name</th>
                                <th>Activity Date</th>
                                <th>Operator Name</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
                <div class="card-footer">
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('after-scripts'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/dataTables/bootstrap4.min.css')); ?>">
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('assets/plugins/dataTables/dataTables.min.js')); ?>"></script>
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('assets/plugins/dataTables/bootstrap4.min.js')); ?>"></script>
    <script>
        var tabel = null;
        $(document).ready(function() {
            tabel = $('#tb_data').DataTable({
                order: [
                    [0, 'desc']
                ],
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('admin.rencana_kerja.datatable')); ?>",
                columns: [
                    { data: 'id', name: 'id', orderable: false, className: "text-center", orderable: false },
                    { data: 'location_code', name: 'location_code' },
                    { data: 'unit_name', name: 'unit_name' },
                    { data: 'implement_name', name: 'implement_name' },
                    { data: 'activity_name', name: 'activity_name' },
                    { data: 'activity_date', name: 'activity_date' },
                    { data: 'operator_name', name: 'operator_name' },
                    {
                        data: "id",
                        render: function(data, type, row, meta) {
                            var btn = ``;
                            btn +=
                                `<div class="btn-group" role="group">
                                    <a class="btn btn-warning" href="<?php echo e(route('admin.rencana_kerja.index')); ?>/` + row.id + `/edit" title="Edit"><i class="fas fa-edit"></i></a>
                                    <form method="POST" name="delete-item" action="<?php echo e(route('admin.rencana_kerja.index')); ?>/` + row.id + `/destroy" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger" style="margin-left: 5px;"><i class="fas fa-trash"></i></button>
                                    </form>
                                </div>`;
                            return btn;
                        },
                        className: "text-center",
                        orderable: false
                    },
                ]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fahmi.robbani\Desktop\laravel9-template-main\resources\views/admin/rencana_kerja/index.blade.php ENDPATH**/ ?>