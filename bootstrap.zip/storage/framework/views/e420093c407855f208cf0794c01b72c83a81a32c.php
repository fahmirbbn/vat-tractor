<div class="container-fluid">
    <?php if(isset($errors) && $errors->any()): ?>
        <div class="alert alert-danger" role="alert">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br />
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(session()->get('flash_success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session()->get('flash_success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->get('flash_warning')): ?>
        <div class="alert alert-warning" role="alert">
            <?php echo e(session()->get('flash_warning')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->get('flash_info') || session()->get('flash_message')): ?>
        <div class="alert alert-info" role="alert">
            <?php echo e(session()->get('flash_info')); ?>

        </div>
    <?php endif; ?>

    <?php if(session()->get('flash_danger')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session()->get('flash_danger')); ?>

        </div>
    <?php endif; ?>

</div>
<?php /**PATH C:\Users\fahmi.robbani\Desktop\laravel9-template-main\resources\views/admin/includes/messages.blade.php ENDPATH**/ ?>