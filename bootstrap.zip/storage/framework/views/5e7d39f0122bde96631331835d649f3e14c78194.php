<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
        <li class="nav-item d-none d-sm-inline-block">
            <a href="<?php echo e(route('index')); ?>" class="nav-link">Home</a>
        </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

        <!-- Messages Dropdown Menu -->
        <li class="nav-item">
            <a class="nav-link" href="#">
                <i class="fas fa-user-circle"></i> <?php echo e($logged_in_user->name); ?>

            </a>
        </li>
    </ul>
</nav>
<?php /**PATH C:\Users\fahmi.robbani\Desktop\laravel9-template-main\resources\views/admin/includes/navbar.blade.php ENDPATH**/ ?>